<?php

    trait loger{
        public function log($mensaje){
            return "Usuario realizó: $mensaje";
        }
    }