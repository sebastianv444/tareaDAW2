<?php

    abstract class Figura{

        abstract public function calcularArea();

    }