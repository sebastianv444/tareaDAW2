<?php

    interface UsuarioBiblioteca{
        public function obtenerID();
        public function mostrarInformacion();
    }