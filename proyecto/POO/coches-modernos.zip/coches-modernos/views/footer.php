  <!-- Footer -->
  <footer>
    <p>&copy; 2023 Coches Modernos. Todos los derechos reservados.</p>
  </footer>
</body>
</html>