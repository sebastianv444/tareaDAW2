<?php include 'header.php'; ?>

<section class="formulario">
  <h2>Has cerrado sesión</h2>
  <p>Gracias por visitar Coches Modernos. Vuelve pronto.</p>
</section>

<?php include 'footer.php'; ?>