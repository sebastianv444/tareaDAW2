<?php include 'header.php'; ?>

<!-- Hero Section -->
<header class="hero">
  <h1>Bienvenido a Coches Modernos</h1>
  <p>Explora nuestro catálogo de coches de última generación.</p>
</header>

<!-- Catálogo de Coches -->
<section id="catalogo" class="catalogo">
  <h2>Catálogo de Coches</h2>
  <div class="coches-container">
    <!-- Ejemplo de coche -->
    <div class="coche-card">
      <img src="https://via.placeholder.com/300x200" alt="Coche Mecánico">
      <h3>Coche Mecánico</h3>
      <p>Diseño clásico con transmisión manual.</p>
      <a href="#" class="btn">Ver Detalles</a>
    </div>
    <!-- Repite este bloque para más coches -->
  </div>
</section>

<?php include 'footer.php'; ?>