<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coches Modernos</title>
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/styles.css">
</head>
<body>
  <!-- Navbar -->
  <nav>
    <div class="logo">CochesModernos</div>
    <ul class="nav-links">
      <li><a href="<?php echo BASE_URL; ?>?page=home">Inicio</a></li>
      <li><a href="#mecanico">Mecánico</a></li>
      <li><a href="#automatico">Automático</a></li>
      <li><a href="#manual">Manual</a></li>
      <li><a href="#electrico">Eléctrico</a></li>
      <li><a href="<?php echo BASE_URL; ?>?page=login">Iniciar Sesión</a></li>
      <li><a href="<?php echo BASE_URL; ?>?page=register">Registrarse</a></li>
      <li><a href="<?php echo BASE_URL; ?>?page=logout">Cerrar Sesión</a></li>
    </ul>
  </nav>