<?php
// index.php (Controlador Frontal)

// Definir la ruta base
define('BASE_URL', '/coches-modernos/');

// Manejo de rutas
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Incluir la vista correspondiente
switch ($page) {
    case 'home':
        include 'views/home.php';
        break;
    case 'login':
        include 'views/login.php';
        break;
    case 'register':
        include 'views/register.php';
        break;
    case 'logout':
        include 'views/logout.php';
        break;
    default:
        include 'views/home.php';
        break;
}
