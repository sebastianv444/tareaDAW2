<footer>
        <p>Colegio El alamillo de Colores &copy;2025</p>
    </footer>
</body>
</html>