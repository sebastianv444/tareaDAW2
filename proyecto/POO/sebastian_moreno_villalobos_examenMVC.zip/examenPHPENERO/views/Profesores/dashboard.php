<section class="dashboard">
    <h1>estas logado</h1>
</section>