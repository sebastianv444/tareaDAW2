<?php
return [
    'host' => 'localhost',
    'database' => 'colegio',
    'username' => 'root',
    'password' => ''
];