<h1>Detalle de películas</h1>

<a href="{{ action('\App\Http\Controllers\PeliculaController@index') }}">Ir al listado </a>
<br>
