<h1><?= $titulo ?></h1>
<h2><?= $premiadas ?></h2>