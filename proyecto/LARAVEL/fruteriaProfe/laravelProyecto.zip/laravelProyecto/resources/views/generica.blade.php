@extends('layouts/master')


@section('titulo', 'primera página')

@section('header')
@parent()
 <h3>hola que tal</h3>
 @stop

@section('contenido')

<h3>Página genérica </h3>

@stop
