<h1>CABECERA</h1>
<hr><?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/includes/header.blade.php ENDPATH**/ ?>