<h1>Detalle de películas</h1>

<a href="<?php echo e(action('\App\Http\Controllers\PeliculaController@index')); ?>">Ir al listado </a>
<br>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/peliculas/detalle.blade.php ENDPATH**/ ?>