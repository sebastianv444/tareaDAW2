<h1>formulario en Laravel</h1>

<!-- para evitar ataques csrf ponemos esto -->



<form action="<?php echo e(action('\App\Http\Controllers\PeliculaController@recibir')); ?>" method="POST">

    <?php echo e(csrf_field()); ?>


 <label for="nombre">Nombre</label>
 <input type="text" name="nombre"/>
 <label for="email">email</label>
 <input type="email" name="email"/>

 <input type="submit"  value="Enviar">

</form>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/peliculas/formulario.blade.php ENDPATH**/ ?>