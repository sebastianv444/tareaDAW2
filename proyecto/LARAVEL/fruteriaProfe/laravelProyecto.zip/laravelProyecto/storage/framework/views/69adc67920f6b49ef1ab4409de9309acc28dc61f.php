<h1>Detalle fruta </h1>

<p>
    <?php echo e($fruta->descripcion); ?>

</p>

<a href="<?php echo e(action('\App\Http\Controllers\FrutaController@borrar', ['id'=>$fruta->id])); ?>">Eliminar </a>
<br>

<a href="<?php echo e(action('\App\Http\Controllers\FrutaController@irAFormularioEditar', ['id'=>$fruta->id])); ?>">Modificar </a>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/fruta/detalle.blade.php ENDPATH**/ ?>