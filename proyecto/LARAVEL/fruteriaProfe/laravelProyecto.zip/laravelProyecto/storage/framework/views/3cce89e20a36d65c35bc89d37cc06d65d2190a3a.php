<?php
 echo "<h1>$titulo</h1>";
 echo date('d-m-Y');
 echo "<br>"; ?><?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/mostrar-fecha.blade.php ENDPATH**/ ?>