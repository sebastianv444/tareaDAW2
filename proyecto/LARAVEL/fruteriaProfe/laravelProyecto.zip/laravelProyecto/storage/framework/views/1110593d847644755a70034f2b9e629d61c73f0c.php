<?php $__env->startSection('titulo', 'primera página'); ?>

<?php $__env->startSection('header'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
 <h3>hola que tal</h3>
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<h3>Página genérica </h3>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/generica.blade.php ENDPATH**/ ?>