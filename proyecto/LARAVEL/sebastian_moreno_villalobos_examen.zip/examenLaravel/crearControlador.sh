#!/bin/bash
/opt/lampp/bin/php artisan make:controller $1
