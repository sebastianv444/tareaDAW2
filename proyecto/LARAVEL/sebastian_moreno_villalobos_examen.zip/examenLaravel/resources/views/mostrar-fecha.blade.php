<?php
 echo "<h1>$titulo</h1>";
 echo date('d-m-Y');
 echo "<br>";