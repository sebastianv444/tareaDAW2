    <footer>
        <p>&copy; 2025 Gestion de Proveedores. Todos los derechos resevados.</p>
    </footer>

</body>
</html>
