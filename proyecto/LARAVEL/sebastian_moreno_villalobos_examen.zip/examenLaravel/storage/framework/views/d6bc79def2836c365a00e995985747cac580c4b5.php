<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section>
        <h1>Acceso Denegado</h1>
        <p>no eres usuario admin!!.</p><br><br>
        <a href="<?php echo e(action('\App\Http\Controllers\InformacionController@index')); ?>">volver al Listado</a>
    </section>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/examenLaravel/resources/views/informacion/denegado.blade.php ENDPATH**/ ?>