<?php

echo "productos"; ?><?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/productos.blade.php ENDPATH**/ ?>