<h1><?php echo e($titulo); ?></h1>

<a href="<?php echo e(action('\App\Http\Controllers\PeliculaController@detalle')); ?>">Ir al detalle </a>
<br>
<a href=" <?php echo e(route('detalle.pelicula', ['id'=> 12])); ?>">Otra forma de ir a detalle </a>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/examenLaravel/resources/views/peliculas/index.blade.php ENDPATH**/ ?>