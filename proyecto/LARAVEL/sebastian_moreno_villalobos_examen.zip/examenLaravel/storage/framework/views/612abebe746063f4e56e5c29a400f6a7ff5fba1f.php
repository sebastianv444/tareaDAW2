<h1>
    Listado de frutas
</h1>

<h3>
    <a href="<?php echo e(action('\App\Http\Controllers\FrutaController@crear')); ?>"> Crear fruta</a>
</h3>

<?php if(session('estado')): ?>
<p style="background: green">
    <?php echo e(session('estado')); ?>

</p>
<?php endif; ?>

<ul>
    <?php $__currentLoopData = $frutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(action('\App\Http\Controllers\FrutaController@detalle', ['id'=>$fruta->id])); ?>">

            <?php echo e($fruta->nombre); ?>


             </a>

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/fruta/index.blade.php ENDPATH**/ ?>