<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section>
    <h1>Listado de Clientes</h1><br>

    <h3>
        <a href= "<?php echo e(action('\App\Http\Controllers\ClienteController@create')); ?>"> Crear cliente </a>
    </h3><br>

    <ul>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(action('\App\Http\Controllers\ClienteController@detalle', [$cliente->id])); ?>"><?php echo e($cliente->nombre); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</section>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/examenLaravel/resources/views/cliente/index.blade.php ENDPATH**/ ?>