<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1><?= $titulo ?></h1>
<h2><?= $listado[0]?></h2>

<?php echo e($titulo); ?>





<br>Con php <br>
<?= isset($director) ? $director : 'no hay director' ?>
<br>
Con Blade <br>
<h3><?php echo e($director ?? 'no tenemos director'); ?></h3>
<hr>
<h1>Estructuras de control</h1>

<h2>1.- CONDICIONALES</h2>
<h4>1.1- If </h4>

<?php if($titulo): ?>
    <h4>El título existe y es: <?php echo e($titulo); ?></h4>
<?php else: ?>
    <h4>El título no existe</h4>
<?php endif; ?>

<?php if($titulo && count($listado) >= 5): ?>
    <h4>El título existe y el listado es mayor o igual  5</h4>
<?php elseif($titulo): ?>
    <h4>El título es:  <?php echo e($titulo); ?> pero el listado es menor que 6</h4>
<?php else: ?>
    <h4>La condición no se ha cumplido</h4>
<?php endif; ?>

<h2>2.- BUCLES</h2>
<h4>2.1- For </h4>

<?php for($i=0; $i < 20; $i++): ?>
    el número es: <?php echo e($i); ?> <br/>
<?php endfor; ?>

<h4>2.2- While </h4>

<?php $contador = 1 ?>

<?php while($contador < 30 ): ?>
    <?php if($contador % 2 == 0): ?>
        NÚMERO PAR: <?php echo e($contador); ?> <br/>
    <?php endif; ?>

    <?php $contador++; ?>
<?php endwhile; ?>

<h4>2.3- Foreach </h4>

<?php $__currentLoopData = $listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <strong><?php echo e($pelicula); ?></strong><br/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

Hello, {{ name }}.

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/peliculas/listado.blade.php ENDPATH**/ ?>