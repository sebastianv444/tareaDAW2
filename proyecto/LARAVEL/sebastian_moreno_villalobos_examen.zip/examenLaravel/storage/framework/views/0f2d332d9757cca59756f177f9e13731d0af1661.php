<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section>
    <table>
        <tr>
            <th>Nombre: </th>
            <th>Email: </th>
            <th>Telefono: </th>
        </tr>
    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(action('\App\Http\Controllers\ClienteController@detalle',[$cliente->id])); ?>"><?php echo e($cliente->nombre); ?></a></td>
            <td><?php echo e($cliente->email); ?></td>
            <td><?php echo e($cliente->telefono); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><br><br>
    <table>
        <tr>
            <th>Nombre: </th>
            <th>Email: </th>
            <th>Telefono: </th>
        </tr>
    <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(action('\App\Http\Controllers\ProveedorController@detalle', [$proveedor->id])); ?>"><?php echo e($proveedor->nombre); ?></a></td>
            <td><?php echo e($proveedor->email); ?></td>
            <td><?php echo e($proveedor->telefono); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</section>


<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/examenLaravel/resources/views/informacion/admin.blade.php ENDPATH**/ ?>