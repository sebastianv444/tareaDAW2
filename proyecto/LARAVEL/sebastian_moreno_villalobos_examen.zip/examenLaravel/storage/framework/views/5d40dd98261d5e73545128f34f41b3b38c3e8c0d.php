    <footer>
        <p>&copy; 2025 Gestion de Proveedores. Todos los derechos resevados.</p>
    </footer>

</body>
</html>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/examenLaravel/resources/views/includes/footer.blade.php ENDPATH**/ ?>