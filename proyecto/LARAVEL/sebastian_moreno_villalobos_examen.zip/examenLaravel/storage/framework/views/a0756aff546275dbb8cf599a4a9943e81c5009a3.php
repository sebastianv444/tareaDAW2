<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section>
    <h1>Listado de proveedores </h1><br>

    <h3>
        <a href= "<?php echo e(action('\App\Http\Controllers\ProveedorController@create')); ?>"> Crear proveedor </a>
    </h3><br>

    <ul>
        <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(action('\App\Http\Controllers\ProveedorController@detalle', [$proveedor->id])); ?>"><?php echo e($proveedor->nombre); ?></a> - <?php echo e($proveedor->email); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</section>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/examenLaravel/resources/views/proveedor/index.blade.php ENDPATH**/ ?>