<?php if(isset($fruta) && is_object($fruta)): ?>
    <h1>Editar fruta</h1>
<?php else: ?>
    <h1> Insertar fruta </h1>
<?php endif; ?>

<form action="<?php echo e(isset($fruta) ?  action('\App\Http\Controllers\FrutaController@actualizar')
 : action('\App\Http\Controllers\FrutaController@salvar')); ?>"

  method="POST">

    <?php echo e(csrf_field()); ?>


    <?php if(isset($fruta) && is_object($fruta)): ?>
        <input type="hidden" name="id" value="<?php echo e(old('id', $fruta->id)); ?>">
    <?php endif; ?>

    <label for="nombre">Nombre</label>
    <input type="text" name="nombre" value= " <?php echo e(old('nombre', $fruta->nombre ?? '')); ?>" />

    <label for="descripcion">descripcion</label>
    <input type="text" name="descripcion" value= " <?php echo e(old('descripcion', $fruta->descripcion ?? '')); ?>" />

    <label for="precio">precio</label>
    <input type="number" name="precio" value= "<?php echo e(old('precio', $fruta->precio ?? 0 )); ?>" />

    <input type="submit" value="guardar" />

</form>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/fruta/crear.blade.php ENDPATH**/ ?>