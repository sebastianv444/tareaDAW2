<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section>
    <h1>Detalle del cliente <?php echo e($cliente->nombre); ?></h1><br>
    <p><b>Email: </b> <?php echo e($cliente->email); ?></p><br>
    <p><b>telefono: </b> <?php echo e($cliente->telefono); ?></p><br>
    <p><b>Dirección: </b> <?php echo e($cliente->direccion); ?></p><br>
    <p><b>Fecha de creación: </b> <?php echo e($cliente->created_at); ?></p><br>
    <p><b>Última actualización: </b> <?php echo e($cliente->updated_at); ?></p><br>
    <a href="<?php echo e(action('\App\Http\Controllers\ClienteController@index')); ?>">Volver al listado</a>
</section>


<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/examenLaravel/resources/views/cliente/detalle.blade.php ENDPATH**/ ?>