<hr>
<h1>PIE DE PÁGINA</h1><?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/includes/footer.blade.php ENDPATH**/ ?>