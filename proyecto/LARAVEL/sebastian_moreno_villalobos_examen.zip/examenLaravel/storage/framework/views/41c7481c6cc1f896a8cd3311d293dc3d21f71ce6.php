<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section>
    <h1>Detalle del proveedor <?php echo e($proveedor->nombre); ?></h1><br>
    <p><b>Email: </b> <?php echo e($proveedor->email); ?></p><br>
    <p><b>telefono: </b> <?php echo e($proveedor->telefono); ?></p><br>
    <p><b>Dirección: </b> <?php echo e($proveedor->direccion); ?></p><br>
    <p><b>Fecha de creación: </b> <?php echo e($proveedor->created_at); ?></p><br>
    <p><b>Última actualización: </b> <?php echo e($proveedor->updated_at); ?></p><br>
    <a href="<?php echo e(action('\App\Http\Controllers\ProveedorController@index')); ?>">Volver al listado</a>
</section>


<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/examenLaravel/resources/views/proveedor/detalle.blade.php ENDPATH**/ ?>