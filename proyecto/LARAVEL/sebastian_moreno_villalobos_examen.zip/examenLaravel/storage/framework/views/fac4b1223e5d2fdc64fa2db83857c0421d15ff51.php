<h1><?= $titulo ?></h1>
<h2><?= $premiadas ?></h2><?php /**PATH /opt/lampp/htdocs/proyecto/LARAVEL/laravelProyecto/resources/views/premiadas.blade.php ENDPATH**/ ?>